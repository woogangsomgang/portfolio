import React from 'react'
import '../css/main.scss'
import '../css/common.scss'
import Logo from './Logo'


function Index() {
    return (


        <div className="main">
            <div className="main-text">
                <p>한 조각의 퍼즐</p>
                <p>JIN</p>
                <p>YUN-SEO</p>
            </div>
            <div className="main-logo"> 
                <Logo />
            </div>
        </div>

    )
}

export default Index

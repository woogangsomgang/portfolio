import React from 'react'
import '../css/common.scss'
import '../css/about.scss'

function About() {


    return (
        <div className='about'>


                <div className="about-me">
                    <h2>About me</h2>
                    <p>: 듣는 개발자🎧</p>
                </div>

                <div className="about-imgs">
                    <img src="./assets/images/profile.jpg" alt="selfie" />
                    <img src="./assets/images/code.png" alt="intro" />
                </div>

                <div className="about-text">
                    <p>저는 음악과 대화를 사랑해요 </p>
                    <p>사랑하는 음악가 대화가 함께라면 어떤 프로젝트든 완성 시킬 수 있어!</p>
                    <p>소통을 두려워하지 않는 개발자 <strong>진윤서</strong> 입니다.</p>
                </div>


                <div className="skills">

                    <p>Skills</p>

                    <p className="skill-name">Frontend</p>
                    <ul className="skill-list">
                        <li><img src="./assets/svg/html5.svg" alt="HTML" /></li>
                        <li><img src="./assets/svg/css3.svg" alt="CSS" /></li>
                        <li><img src="./assets/svg/javascript.svg" alt="JavaScript" /></li>
                        <li><img src="./assets/svg/nodejs.svg" alt="Node.js" /></li>
                        <li><img src="./assets/svg/react.svg" alt="React" /></li>
                    </ul>
                    <div className="line"></div>

                    <p className="skill-name">Backend</p>
                    <ul className="skill-list">
                        <li><img src="./assets/svg/nextjs.svg" alt="next.js" /></li>
                    </ul>
                    <div className="line"></div>

                    <p className="skill-name">Database</p>
                    <ul className="skill-list">
                        <li><img src="./assets/svg/mongodb.svg" alt="MongoDB" /></li>
                    </ul>
                    <div className="line"></div>

                    <p className="skill-name">Tools</p>
                    <ul className="skill-list">
                        <li><img src="./assets/svg/git.svg" alt="git" /></li>
                        <li><img src="./assets/svg/GitHub.svg" alt="gitHub" /></li>
                        <li><img src="./assets/svg/figma.svg" alt="figma" /></li>
                        <li><img src="./assets/svg/vscode.svg" alt="Vscode" /></li>
                    </ul>
                    <div className="line"></div>

                </div>

        </div>
    )
}

export default About


